package com.jogador.futebol.repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import com.jogador.futebol.models.Pagamento;

public interface PagamentoRepo  extends JpaRepository<Pagamento, Long>{

}
