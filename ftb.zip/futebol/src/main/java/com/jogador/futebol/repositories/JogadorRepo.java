package com.jogador.futebol.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jogador.futebol.models.Jogador;

public interface JogadorRepo extends JpaRepository<Jogador, Long> {

}
